
type t = 
    {
      arecord: int
    } with odn

(* END EXPORT *)

(* SHOULD NOT BE THERE *)

(* START EXPORT *)

(* SHOULD BE THERE *)
