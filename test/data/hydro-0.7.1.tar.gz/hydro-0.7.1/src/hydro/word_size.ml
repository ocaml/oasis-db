print_int (Sys.word_size);
print_newline();;
