(* OASIS_START *)
(* DO NOT EDIT (digest: 5637fb2c69473d31640e3b3b32d52c3d) *)
This is the README file for the ocaml-data-notation distribution.

(C) 2009-2010 OCamlCore SARL

Store data using OCaml notation

This library uses `type-conv` to dump OCaml data structures using OCaml data
notation.

This kind of data dumping helps to write OCaml code generator, like OASIS.

See the files INSTALL.txt for building and installation instructions. See the
file COPYING.txt for copying conditions. 

Home page: http://forge.ocamlcore.org/projects/odn


(* OASIS_STOP *)
