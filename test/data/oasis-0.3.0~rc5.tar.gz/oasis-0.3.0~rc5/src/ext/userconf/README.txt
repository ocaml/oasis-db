This directory contains an implementation of a user configuration management
system that helps to define a configurable key/value store that the user can
set.

Plan support:
- environment variable
- command line argument
- .ini files
- .lua files (for dynamic configuration)
