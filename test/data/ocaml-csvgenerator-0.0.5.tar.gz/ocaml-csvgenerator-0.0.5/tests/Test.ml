
(** Test suite for ocaml-csvgenerator
    @author Sylvain Le Gall
  *)

open OUnit;;

let prog base = 
  try 
    List.find
      Sys.file_exists 
      [base^".native";
       base^".byte"]
  with Not_found ->
    failwith 
      ("Cannot find program "^base)
;;

let csv_analyze = 
  prog "../_build/src/csv-analyze/CsvAnalyze"
;;

let csv_generate =
  prog "../_build/src/csv-generate/CsvGenerate"
;;

let in_data_dir fn =
  Filename.concat "data" fn 
;;

let bracket_tmpfile f =
  bracket
    (fun () ->
       Filename.temp_file "ocaml-csvgenerator" ".csv")
    f
    Sys.remove
;;

let test_with_generate_checksum (fn, sz, seed, ck) = 
  let end_cli = 
    String.concat " " 
      [Filename.quote (in_data_dir fn); 
       "-n"; string_of_int sz; 
       "-s"; (string_of_int seed);
       "-q"]
  in
    (Printf.sprintf 
       "csv-generate %s->%s"
       end_cli
       ck) >::
     bracket_tmpfile
       (fun fntmp ->
          let cli =
            String.concat 
              " " 
              [
                Filename.quote csv_generate;
                "-o"; Filename.quote fntmp;
                end_cli
              ]
          in
            assert_equal
              ~msg:"Exit code"
              ~printer:string_of_int
              0
              (Sys.command cli);
            assert_equal
              ~msg:"Checksum of generated file"
              ~printer:(fun s -> s)
              ck
              (Digest.to_hex (Digest.file fntmp)))
;;
              
let _ = 
  run_test_tt_main
    ("ocaml-csvgenerator" >:::
     [
       "Generate" >:::
       (List.map 
          test_with_generate_checksum
          [
            "customer.sig",   100, 123456, "79ae23669c046b9335c20dad22e31699";
            "lineitem.sig",   100, 123456, "32184ea97d25a3efad6c8c3bbc16292a";
            "nation.sig",     100, 123456, "1732abfd925bfeeb1191ebc8d13d5dc1";
            "orders.sig",     100, 123456, "a6c9285fb98117fb18a978046f6b7b24";
            "part.sig",       100, 123456, "8ff0714ada9083ff3057ee99c0fc5c49";
            "partsupp.sig",   100, 123456, "6072806bb39170b71d1ad2e6beaccecb";
            "region.sig",     100, 123456, "9bd951da4058b1324ba03149b1b62ff8";
            "supplier.sig",   100, 123456, "34382b051dc25d80f205c8aec9d9f3e6";
            "customer.sig",  1000, 123456, "7d31abfea737acd3c822e2d7bc894deb";
            "lineitem.sig",  1000, 123456, "fd03aa67493bdf56366414e237753fa9";
            "nation.sig",    1000, 123456, "3adb198a2d89ca98373515e9d890aeb9";
            "orders.sig",    1000, 123456, "e211fcfd26bdf3a798933e8012fb245d";
            "part.sig",      1000, 123456, "bf1306ef74135f52937199a8de9fa986";
            "partsupp.sig",  1000, 123456, "561861cd9369817febd84b6bf068d2d7";
            "region.sig",    1000, 123456, "ba78c011ff424907a34fee3550a18437";
            "supplier.sig",  1000, 123456, "1b150f9757f84e29fb1a7b641e54adfd";
            "customer.sig", 10000, 123456, "016003e0ea996991eaf767ce25446b09";
            "lineitem.sig", 10000, 123456, "12ae0f2556b16fcab49dc82f275b9da9";
            "nation.sig",   10000, 123456, "5c0d7136c8d271bc6f1c27e9177eb060";
            "orders.sig",   10000, 123456, "17511d7880e51f5513c703901e72bd1c";
            "part.sig",     10000, 123456, "e52f51cc44f06abc508448015f1236fb";
            "partsupp.sig", 10000, 123456, "59c171026765a78ef64f7a2387e7a275";
            "region.sig",   10000, 123456, "40cceba70ce374ea9e99c5e56e56f68e";
            "supplier.sig", 10000, 123456, "95d3e31e53859f150a71adaee87c4e63";
          ])
     ])
;;
