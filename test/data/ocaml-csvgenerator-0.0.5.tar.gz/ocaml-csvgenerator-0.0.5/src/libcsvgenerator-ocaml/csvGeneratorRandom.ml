
(** Random module for CSV generator
    @author Sylvain Le Gall
  *)

let init ?seed () =
  match seed with 
    | Some rnd ->
        FastRandom.init rnd
    | None ->
        FastRandom.self_init ()
;;

let int =
  FastRandom.int
;;
