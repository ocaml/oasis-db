(***************************************************************************)
(*  ocaml-csvgenerator : utilities to generate CSV file                    *)
(*                                                                         *)
(*  Copyright (C) 2008 Sylvain Le Gall <sylvain.le-gall@ocamlcore.com>     *)
(*                                                                         *)
(*  This library is free software; you can redistribute it and/or modify   *)
(*  it under the terms of the GNU Lesser General Public License as         *)
(*  published by the Free Software Foundation; either version 2.1 of the   *)
(*  License, or (at your option) any later version; with the special       *)
(*  exception on linking described in the file COPYING at the top of this  *)
(*  source directory.                                                      *)
(*                                                                         *)
(*  This library is distributed in the hope that it will be useful, but    *)
(*  WITHOUT ANY WARRANTY; without even the implied warranty of             *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU      *)
(*  Lesser General Public License for more details.                        *)
(*                                                                         *)
(*  You should have received a copy of the GNU Lesser General Public       *)
(*  License along with this library; if not, write to the Free Software    *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307    *)
(*  USA                                                                    *)
(*                                                                         *)
(***************************************************************************)


(** Statistical distribution for CsvGenerator
  * @author Sylvain Le Gall
  *)

open CsvGeneratorTypes
;;

open CsvGeneratorUtils
;;

open Sexplib.Conv
;;

module type S =
sig
  type t

  type event 

  val default: unit -> t

  val get: event -> t -> int

  val add: event -> t -> unit

  val set: event -> int -> t -> unit

  (** Generate a function which as the same event distribution
    * as the one represented by t. 
    *) 
  val generator: t -> (unit -> event)

  val sexp_of_t: t -> Sexplib.Sexp.t

  val t_of_sexp: Sexplib.Sexp.t -> t
end
;;

module Make (Event: EventType): S with 
type event = Event.t =
struct
  module HE = Hashtbl.Make(Event)

  type t = int HE.t

  type event = Event.t

  let default () =
    HE.create 1000

  let get ev t =
    try
      HE.find t ev
    with Not_found ->
      0

  let set ev cnt t =
    HE.replace t ev cnt 

  let add ev t =
    set ev ((get ev t) + 1) t

  let generator t =
    let (max, lst_event, lst_count) =
      HE.fold
        (fun e count (max, elst, clst) -> max + count, e :: elst, count :: clst)
        t
        (0, [], [])
    in
      if List.length lst_event = 1 then
        (
          let single_event = 
            List.hd lst_event
          in
            fun () ->
              let _i : int =
                CsvGeneratorRandom.int max
              in
                single_event
        )
      else if List.length lst_event < 1024 then
        (
          let arr = 
            let lst = 
              List.combine lst_event lst_count
            in
            let a =
              Array.make max Event.min
            in
            let last =
              List.fold_left
                (fun i (e, count) ->
                   Array.fill a i count e;
                   i + count)
                0
                lst
            in
              assert(last = Array.length a);
              a
          in
          let peek_event () =
            Array.unsafe_get 
              arr 
              (CsvGeneratorRandom.int max);
          in
            peek_event 
        )
      else
        (
          let arr_event = 
            Array.of_list lst_event
          in
          let arr_count =
            Array.of_list lst_count
          in
          let rec peek_event_aux i cnt =
            let curr =
              Array.unsafe_get arr_count i
            in
              if cnt < curr then
                Array.unsafe_get arr_event i
              else
                peek_event_aux (i + 1) (cnt - curr)
          in
          let peek_event () =
            peek_event_aux 
              0
              (CsvGeneratorRandom.int max)
          in
            peek_event 
        )

  let sexp_of_t =
    sexp_of_mapping 
      HE.fold
      Event.sexp_of_t
      sexp_of_int

  let t_of_sexp t =
    mapping_of_sexp
      (fun ev cnt t -> HE.add t ev cnt; t)
      Event.t_of_sexp
      int_of_sexp
      (default ())
      t

end
;;

