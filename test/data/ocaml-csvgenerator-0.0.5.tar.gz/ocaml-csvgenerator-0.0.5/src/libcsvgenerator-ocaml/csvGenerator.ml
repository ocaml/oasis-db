(***************************************************************************)
(*  ocaml-csvgenerator : utilities to generate CSV file                    *)
(*                                                                         *)
(*  Copyright (C) 2008 Sylvain Le Gall <sylvain.le-gall@ocamlcore.com>     *)
(*                                                                         *)
(*  This library is free software; you can redistribute it and/or modify   *)
(*  it under the terms of the GNU Lesser General Public License as         *)
(*  published by the Free Software Foundation; either version 2.1 of the   *)
(*  License, or (at your option) any later version; with the special       *)
(*  exception on linking described in the file COPYING at the top of this  *)
(*  source directory.                                                      *)
(*                                                                         *)
(*  This library is distributed in the hope that it will be useful, but    *)
(*  WITHOUT ANY WARRANTY; without even the implied warranty of             *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU      *)
(*  Lesser General Public License for more details.                        *)
(*                                                                         *)
(*  You should have received a copy of the GNU Lesser General Public       *)
(*  License along with this library; if not, write to the Free Software    *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307    *)
(*  USA                                                                    *)
(*                                                                         *)
(***************************************************************************)


(** CSV generator common data structure
  * @author Sylvain Le Gall
  *)

TYPE_CONV_PATH "CsvGenerator"

open CsvGeneratorTypes
;;

open CsvGeneratorUtils
;;

open Sexplib.Conv
;;

module DI = CsvGeneratorDistribution.Make(IntEvent)
;;

module MDC = CsvGeneratorMarkovDistribution.Make(CharEvent)
;;

module MF = 
struct
  include Map.Make(
  struct
    type t = int
    let compare a  b = a - b
  end)

  let sexp_of_t sexp_of_value t =
    sexp_of_mapping
      fold
      sexp_of_int
      sexp_of_value
      t

  let t_of_sexp value_of_sexp st =
    mapping_of_sexp 
      add
      int_of_sexp
      value_of_sexp
      empty
      st

end
;;

type filename = string
;;

type progress_message =
  | ProgressBegin
  | ProgressComplete of float
  | ProgressEnd
;;

type progress_function = progress_message -> unit
;;

type file_stat =
    {
      (** Field separator
        *)
      separator: char;

      (** Typical number of entry in a file 
        *)
      entry_number: DI.t;

      (** Typical number of field per entry
        *)
      field_number: DI.t;

      (** Typical lengh of a field per field
        *)
      field_length: DI.t MF.t;

      (** Typical content of field per field
        *)
      field_content: MDC.t MF.t;
    } with sexp
;;


(** Version
  *)
let version =
  CsvGeneratorConfig.version
;;

(** The default file statistic
  *)
let default c =
  {
    separator     = c;
    entry_number  = DI.default ();
    field_number  = DI.default ();
    field_length  = MF.empty;
    field_content = MF.empty;
  }
;;

type read_state =
    {
      line:                  string;
      line_length:           int;
      current_field:         int;
      pos_field_begin:       int;
      t:                     file_stat;
    }
;;

(* Read a file and update statistics
 *)
let analyze ?(progress=ignore) ?(skip=0) fn t =
  (* Memorize the separtor *)
  let sep =
    t.separator
  in

  (* Get rid of \013 at the end of the line (unix/dos conversion) *)
  let getl_no_eol line =
    if String.length line > 0 then
      (
        let last_char =
          String.get line ((String.length line) - 1)
        in
          if last_char = '\013' then
            String.sub line 0 ((String.length line) - 1)
          else
            line
      )
    else
      line
  in

  (* Get rid of the last empty line *)
  let getl_no_last_empty_line eof line =
    if eof () && (line = "") then
      raise End_of_file
    else
      line
  in

  (* Function to fetch a char from file *)
  let (pos_in,size_in,getl) =
    let chn =
      open_in_bin fn
    in
    let () = 
      for i = 0 to (skip - 1) do 
        ignore(input_line chn)
      done
    in
    let size_in = 
       LargeFile.in_channel_length chn
    in
    let eof () =
      LargeFile.pos_in chn >= size_in
    in
      (fun () -> LargeFile.pos_in chn),
      size_in,
      (fun () -> 
         getl_no_last_empty_line eof
           (getl_no_eol 
              (input_line chn)
           )
      )
  in

  let getl_with_progress =
    let counter =
      ref 0
    in
    let size =
      Int64.to_float size_in
    in
      (fun () ->
         incr counter;
         (
           if !counter = 1 then
             (
               let pos =
                 Int64.to_float (pos_in ())
               in
                 progress (ProgressComplete (pos /. size));
             )
           else if !counter > 1000 then
             (
               counter := 0
             )
           else
             ()
         );
         getl ()
      )
  in

  (* Find or return default value *)
  let find_default i mp default =
    try
      (mp, MF.find i mp)
    with Not_found ->
      (
        let nval = 
          default ()
        in
        let nmp =
          MF.add i nval mp
        in
          (nmp, nval)
      )
  in

  (* Create a read state for the first field encounter *)
  let read_state_first_field t line =
    {
      line                  = line;
      line_length           = String.length line;
      current_field         = 0;
      pos_field_begin       = -1;
      t                     = t;
    }
  in

  (* Read state pointing to the next field *)
  let read_state_next_field rt pos =
    (* Put back former data *)
    let nfield_length =
      let (nfield_length, cur_field_length) = 
        find_default rt.current_field rt.t.field_length DI.default
      in
        DI.add (pos - rt.pos_field_begin - 1) cur_field_length;
        nfield_length
    in
    let nfield = 
      rt.current_field + 1
    in
      (* Update associated value *)
      {
        rt with
            current_field         = nfield;
            pos_field_begin       = pos;
            t = 
              {
                rt.t with 
                    field_length = nfield_length
              }
      }
  in

  let get_field_content rt =
    let (nfield_content, field_content) = 
      find_default rt.current_field rt.t.field_content MDC.default
    in
    let nrt = 
      {
        rt with 
            t = 
              {
                rt.t with
                    field_content = nfield_content;
              }
      }
    in 
      nrt, field_content
  in


  (* Read an entry and update number of field *)
  let add_entry t line =
    let rec add_entry_aux rt field_content pos =
      if pos < rt.line_length then
        (
          let c =
            String.get rt.line pos 
          in
            if c = sep then
              let nrt = 
                read_state_next_field 
                  rt
                  pos
              in
              let (nnrt, field_content) = 
                get_field_content nrt
              in
                add_entry_aux 
                  nnrt
                  (MDC.put_end field_content)
                  (pos + 1)
            else
              add_entry_aux 
                rt
                (MDC.put c field_content)
                (pos + 1)
        )
      else
        (
          read_state_next_field 
            rt
            pos
        )
    in
    let rt = 
      read_state_first_field t line
    in
    let nrt =
      let (nrt, field_content) = 
        get_field_content rt
      in
      add_entry_aux 
        nrt
        field_content 
        0
    in
      DI.add nrt.current_field nrt.t.field_number;
      nrt.t
  in

  (* Read a file and update its number of entry *)
  let rec add_file_aux i t =
      let line =
        try 
          Some (getl_with_progress ())
        with End_of_file ->
          None
      in
        match line with 
          | Some str ->
              (
                let nt =
                  add_entry t str
                in
                  add_file_aux (i + 1) nt
              )
          | None ->
              (
                DI.add i t.entry_number;
                t
              )
  in
  let res =
    progress ProgressBegin;
    add_file_aux 0 t
  in
    progress ProgressEnd;
    res
;;

(*
let slice rnd max_size = 
  (* Run random number generator to know how much data to fetch
   * and the state of the random number generator
   *)

;;

let generate rnd max_size = 
;;

let slave () = 
  ...
;;
 *)

(* Generate a file using statistics 
 *)
let generate ?(progress=ignore) ?(seed) ?(entries) t chn =
  let () = 
    CsvGeneratorRandom.init ?seed ()
  in

  (* Transform every file statistic into random generator *)
  let entry_number_gen = 
    DI.generator t.entry_number 
  in
  let field_number_gen =
    DI.generator t.field_number 
  in

  (* Transform a map into an array, return real rank of element 0
     and array.
   *)
  let array_of_map mp gen dflt = 
    let (fmin, fmax) = 
      MF.fold 
        (fun k _ (fmin, fmax) -> min k fmin, max k fmax)
        mp
        (IntEvent.max, IntEvent.min)
    in
    let arr =
      Array.init
        (fmax + 1 - fmin) 
        (fun i -> 
           try 
             let e = 
               MF.find (i + fmin) mp
             in
               gen e
           with Not_found ->
             dflt)
    in
      fmin, arr
  in
  let field_length_min, field_length_gen =
    array_of_map 
      t.field_length 
      DI.generator
      (fun () -> failwith "Unknow field length generator")
  in
  let field_content_min, field_content_gen = 
    array_of_map
      t.field_content
      MDC.generator 
      (fun _ _ -> failwith "Unknown field content generator")
  in

  (* Generate a field *)
  let generate_field buff fld =
    let len = 
      field_length_gen.(fld - field_length_min) ()
    in
      field_content_gen.(fld - field_content_min) buff len
  in

  (* Generate an entry *)
  let generate_entry buff =
    let num_fld =
      field_number_gen ()
    in
      for i = 0 to num_fld - 1 do
        if i <> 0 then
          Buffer.add_char buff t.separator;
        generate_field buff i;
      done
  in

  (* Number of entries *)
  let num_entries =
    match entries with 
      | Some i ->
          i
      | None ->
          entry_number_gen ()
  in

  (* Generate a file *)
  let buff = 
    Buffer.create 32
  in
    progress ProgressBegin;
    for i = 0 to num_entries do
      progress (ProgressComplete ((float_of_int i) /. (float_of_int num_entries)));
      generate_entry buff;
      Buffer.add_char buff '\n';
      Buffer.output_buffer chn buff;
      Buffer.clear buff
    done;
    progress ProgressEnd
;;
 
(** Write all statistics to a channel
  *)
let output chn t =
  Sexplib.Sexp.output_hum chn (sexp_of_file_stat t)
;;

(** Read all statistics from a channel
  *)
let input chn =
  file_stat_of_sexp (Sexplib.Sexp.input_sexp chn )
;;

(** Generate a string describing statistics
  *)
let to_string t =
  Sexplib.Sexp.to_string_hum (sexp_of_file_stat t)
;;

(** Read the string describing statistics
  *)
let of_string str =
  file_stat_of_sexp (Sexplib.Sexp.of_string str)
;;

(** Progress message *)
let progress msg factor =
  let factor_float =
    float_of_int factor
  in
  let previous =
    ref 0.0
  in
  fun p ->
    let pf =
      Printf.printf "%s: %3.0f%%\r%!" msg
    in
    match p with 
      | ProgressBegin ->
          pf 0.0
      | ProgressComplete complete ->
          let current = 
            (complete *. 100.0 /. factor_float)
          in
            if !previous = 0.0 || current -. !previous >= 1.0 then
              (
                previous := current;
                pf current
              )
      | ProgressEnd ->
          pf 100.0; 
          print_newline ()
;;
 
