(***************************************************************************)
(*  ocaml-csvgenerator : utilities to generate CSV file                    *)
(*                                                                         *)
(*  Copyright (C) 2008 Sylvain Le Gall <sylvain.le-gall@ocamlcore.com>     *)
(*                                                                         *)
(*  This library is free software; you can redistribute it and/or modify   *)
(*  it under the terms of the GNU Lesser General Public License as         *)
(*  published by the Free Software Foundation; either version 2.1 of the   *)
(*  License, or (at your option) any later version; with the special       *)
(*  exception on linking described in the file COPYING at the top of this  *)
(*  source directory.                                                      *)
(*                                                                         *)
(*  This library is distributed in the hope that it will be useful, but    *)
(*  WITHOUT ANY WARRANTY; without even the implied warranty of             *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU      *)
(*  Lesser General Public License for more details.                        *)
(*                                                                         *)
(*  You should have received a copy of the GNU Lesser General Public       *)
(*  License along with this library; if not, write to the Free Software    *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307    *)
(*  USA                                                                    *)
(*                                                                         *)
(***************************************************************************)

(** Common types for CsvGenerator 
  * @author Sylvain Le Gall
  *)

TYPE_CONV_PATH "CsvGeneratorTypes"

module type EventType =
sig
  (** The type of the event.
    *)
  type t 

  (** The equality predicate used to compare event.
    *)
  val equal : t -> t -> bool

  (** A hashing function on keys.
    *)
  val hash : t -> int

  (** Smaller possible event
    *)
  val min: t 

  (** Greater possible event
    *)
  val max: t

  (** Mapping from event to int space
    *)
  val to_rank: t -> int

  (** Mapping from int to event space
    *)
  val of_rank: int -> t

  (** Convert to a string 
    *)
  val to_string: t -> string

  (** Add to buffer
    *)
  val buffer_add: Buffer.t -> t -> unit

  (** Convert event to S-Expression
    *)
  val sexp_of_t: t -> Sexplib.Sexp.t

  (** Convert S-Expression to event
    *)
  val t_of_sexp: Sexplib.Sexp.t -> t
end
;;

module IntEvent: EventType with 
type t = int =
struct
  type t = int with sexp

  let equal a b = 
    a = b

  let hash t = 
    t

  let min =
    min_int

  let max =
    max_int

  let to_rank t =
    t

  let of_rank t =
    t

  let to_string =
    string_of_int

  let buffer_add b t =
    Buffer.add_string b (string_of_int t)
end
;;

module CharEvent: EventType with 
type t = char =
struct
  type t = char with sexp

  let equal a b =
    a = b

  let hash t =
    Char.code t

  let min =
    Char.chr 0

  let max =
    Char.chr 255

  let to_rank =
    Char.code 

  let of_rank =
    Char.chr

  let to_string = 
    String.make 1

  let buffer_add =
    Buffer.add_char 
        
end
;;
