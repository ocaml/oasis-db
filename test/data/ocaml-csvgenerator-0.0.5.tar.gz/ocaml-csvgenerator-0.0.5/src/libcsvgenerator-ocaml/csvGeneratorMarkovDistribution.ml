(***************************************************************************)
(*  ocaml-csvgenerator : utilities to generate CSV file                    *)
(*                                                                         *)
(*  Copyright (C) 2008 Sylvain Le Gall <sylvain.le-gall@ocamlcore.com>     *)
(*                                                                         *)
(*  This library is free software; you can redistribute it and/or modify   *)
(*  it under the terms of the GNU Lesser General Public License as         *)
(*  published by the Free Software Foundation; either version 2.1 of the   *)
(*  License, or (at your option) any later version; with the special       *)
(*  exception on linking described in the file COPYING at the top of this  *)
(*  source directory.                                                      *)
(*                                                                         *)
(*  This library is distributed in the hope that it will be useful, but    *)
(*  WITHOUT ANY WARRANTY; without even the implied warranty of             *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU      *)
(*  Lesser General Public License for more details.                        *)
(*                                                                         *)
(*  You should have received a copy of the GNU Lesser General Public       *)
(*  License along with this library; if not, write to the Free Software    *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307    *)
(*  USA                                                                    *)
(*                                                                         *)
(***************************************************************************)

(** Statistical distribution using Markov chain for CsvGenerator
  * @author Sylvain Le Gall
  *)

TYPE_CONV_PATH "CsvGeneratorMarkovDistribution"

open CsvGeneratorTypes;;

open Sexplib.Conv;;

module type S =
sig
  type t

  type event

  val default: unit -> t

  val put: event -> t -> t

  val put_end: t -> t
                           
  val generator: t -> (Buffer.t -> int -> unit)

  val sexp_of_t: t -> Sexplib.Sexp.t
  
  val t_of_sexp: Sexplib.Sexp.t -> t
end
;;

module Make (Event: EventType): S with
type event = Event.t =
struct

  type transition = 
      { 
        event_from: Event.t;
        event_to: Event.t;
      }

  type event = Event.t

  module Distribution = CsvGeneratorDistribution.Make(Event)

  (* Storage section *)
  module Storage =
  struct

    type t = int array array 

    let default () =
      let dim =
        (Event.to_rank Event.max) - (Event.to_rank Event.min) + 1
      in
      (Array.make_matrix dim dim 0)

    let rank_base =
      Event.to_rank Event.min

    let rank_rebase ev =
      (Event.to_rank ev) - rank_base

    let get trs t =
      t.(rank_rebase trs.event_from).(rank_rebase trs.event_to)

    let set trs i t =
      t.(rank_rebase trs.event_from).(rank_rebase trs.event_to) <- i

    let incr trs t =
      set trs ((get trs t) + 1) t
    
    let to_list t =
      let acc = 
        ref []
      in
      for i = rank_rebase Event.min to rank_rebase Event.max do
        for j = rank_rebase Event.min to rank_rebase Event.max do
          if t.(i).(j) <> 0 then
            acc := (Event.of_rank i, Event.of_rank j, t.(i).(j)) :: !acc
        done
      done;
      !acc

    let of_list lst =
      let rec of_list_aux t lst =
        match lst with
          | (i, j, v) :: tl ->
              t.(Event.to_rank i).(Event.to_rank j) <- v;
              of_list_aux t tl 
          | [] ->
              t
      in
        of_list_aux (default ()) lst


    let sexp_of_t t = 
      let lst =
        to_list t
      in
        sexp_of_list 
          (sexp_of_triple
             Event.sexp_of_t
             Event.sexp_of_t
             sexp_of_int)
          lst

    let t_of_sexp st =
      let lst =
        list_of_sexp
          (triple_of_sexp
             Event.t_of_sexp
             Event.t_of_sexp
             int_of_sexp)
          st
      in
        of_list lst

  end

  type t = 
      {
        state:      Event.t option;
        first:      Distribution.t;
        transition: Storage.t;
      } with sexp

  let default () = 
    {
      state      = None;
      transition = Storage.default ();
      first      = Distribution.default ();
    }

  let put e t =
    let () =
      match t.state with 
        | Some pe ->
            Storage.incr 
              {
                event_from = pe; 
                event_to = e
              } 
              t.transition
        | None ->
            (
              (* First event, record it *)
              Distribution.add e t.first
            )
    in
      {
        t with 
            state = Some e;
      }

  let put_end t =
    {
      t with 
          state = None;
    }

  let generator t =
    let first_generator =
      Distribution.generator t.first 
    in

    let lst =
      Storage.to_list t.transition
    in

    let start, len =
      let rank_list = 
        List.fold_left
          (fun acc (e_from, e_to, _) ->
             (Event.to_rank e_from) :: (Event.to_rank e_to) :: acc)
          []
          lst
      in
      let imin =
        List.fold_left
          min
          (Event.to_rank Event.max)
          rank_list
      in
      let imax =
        List.fold_left
          max
          (Event.to_rank Event.min)
          rank_list
      in
        imin, max (imax - imin + 1) 0
    in

    let event_get arr e = 
      Array.unsafe_get arr ((Event.to_rank e) - start)
    in

    let event_set arr e v = 
      arr.((Event.to_rank e) - start) <- v
    in

    let arr_generator =
      let arr_distribution =
        Array.make
          len
          None
      in
        List.iter 
          (fun (e_from, e_to, cnt) ->
             let dt =
               match event_get arr_distribution e_from with 
                 | Some dt -> 
                     dt
                 | None ->
                     Distribution.default ()
             in
               event_set arr_distribution e_from (Some dt);
               Distribution.set e_to cnt dt)
          lst;
        Array.map
          (function 
             | Some dt -> Distribution.generator dt
             | None -> first_generator)
          arr_distribution
    in

    let rec generator_aux last buff len = 
      if len > 0 then
        (
          let e = 
            (event_get arr_generator last) ()
          in
            Event.buffer_add buff e;
            generator_aux e buff (len - 1)
        )
    in
    let generator_start buff len =
      if len > 0 then
        (
          let e = 
            first_generator ()
          in
            Event.buffer_add buff e;
            generator_aux e buff (len - 1)
        )
    in
      generator_start

end
;;


