(***************************************************************************)
(*  ocaml-csvgenerator : utilities to generate CSV file                    *)
(*                                                                         *)
(*  Copyright (C) 2008 Sylvain Le Gall <sylvain.le-gall@ocamlcore.com>     *)
(*                                                                         *)
(*  This library is free software; you can redistribute it and/or modify   *)
(*  it under the terms of the GNU Lesser General Public License as         *)
(*  published by the Free Software Foundation; either version 2.1 of the   *)
(*  License, or (at your option) any later version; with the special       *)
(*  exception on linking described in the file COPYING at the top of this  *)
(*  source directory.                                                      *)
(*                                                                         *)
(*  This library is distributed in the hope that it will be useful, but    *)
(*  WITHOUT ANY WARRANTY; without even the implied warranty of             *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU      *)
(*  Lesser General Public License for more details.                        *)
(*                                                                         *)
(*  You should have received a copy of the GNU Lesser General Public       *)
(*  License along with this library; if not, write to the Free Software    *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307    *)
(*  USA                                                                    *)
(*                                                                         *)
(***************************************************************************)

(** Various utils functions for CsvGenerator.
  * @author Sylvain Le Gall
  *)

open Sexplib.Conv
;;

let sexp_of_mapping fold sexp_of_key sexp_of_value t =
  sexp_of_list
    (fun st -> st)
    (fold 
       (fun k v lst ->
          let st =
            sexp_of_pair
              sexp_of_key
              sexp_of_value
              (k, v)
          in
            st :: lst)
       t
       [])
;;

let mapping_of_sexp add key_of_sexp value_of_sexp default st =
  let lst =
    list_of_sexp
      (pair_of_sexp
         key_of_sexp
         value_of_sexp)
      st
  in
    List.fold_left 
      (fun t (ev,cnt) -> add ev cnt t)
      default
      lst
;;

