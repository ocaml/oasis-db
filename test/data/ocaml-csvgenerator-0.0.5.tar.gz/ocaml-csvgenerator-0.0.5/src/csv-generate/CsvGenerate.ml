(***************************************************************************)
(*  ocaml-csvgenerator : utilities to generate CSV file                    *)
(*                                                                         *)
(*  Copyright (C) 2008 Sylvain Le Gall <sylvain.le-gall@ocamlcore.com>     *)
(*                                                                         *)
(*  This library is free software; you can redistribute it and/or modify   *)
(*  it under the terms of the GNU Lesser General Public License as         *)
(*  published by the Free Software Foundation; either version 2.1 of the   *)
(*  License, or (at your option) any later version; with the special       *)
(*  exception on linking described in the file COPYING at the top of this  *)
(*  source directory.                                                      *)
(*                                                                         *)
(*  This library is distributed in the hope that it will be useful, but    *)
(*  WITHOUT ANY WARRANTY; without even the implied warranty of             *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU      *)
(*  Lesser General Public License for more details.                        *)
(*                                                                         *)
(*  You should have received a copy of the GNU Lesser General Public       *)
(*  License along with this library; if not, write to the Free Software    *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307    *)
(*  USA                                                                    *)
(*                                                                         *)
(***************************************************************************)

(** Generate CSV file
  *)

type filename = string
;;

type configuration =
    {
      entries:  int option;
      input:    filename option;
      output:   filename option;
      verbose:  bool;
      seed:     int option;
    }
;;


let parse_args () =
  let conf =
    ref 
      {
        entries = None;
        input   = None;
        output  = None;
        verbose = true;
        seed    = None;
      }
  in
  let args =
    [
      ("-n",
       Arg.Int
         (
           fun i ->
             conf := {!conf with entries = Some i}
         ),
       "num Number of entries to generate"
      );

      ("-o",
       Arg.String
         (
           fun str ->
             conf := {!conf with output = Some str}
         ),
       "filename CSV file to generate"
      );

      ("-q",
       Arg.Unit
         (
           fun () ->
             conf := {!conf with verbose = false}
         ),
       " Be quiet"
      );

      ("-s",
       Arg.Int
         (
           fun i ->
             conf := {!conf with seed = Some i}
         ),
       "rnd Random seed"
      );
    ]
  in
    Arg.parse
      args 
      (fun str -> conf := {!conf with input = Some str})
      (
        "csv-generate v"^CsvGenerator.version^" written by Sylvain Le Gall <sylvain.le-gall@ocamlcore.com>\n"^
        "\n"^
        "Usage: csv-generate [option] [input file]\n"^
        "\n"^
        " Options: \n"
      );
    !conf 
;;

let () = 
  let conf =
    parse_args ()
  in
  let progress = 
    if conf.verbose then
      (CsvGenerator.progress "Writing file" 1)
    else
      (fun _ -> ())
  in
  let (chn_in, close_in) = 
    match conf.input with 
      | Some f ->
          (
            let chn =
              open_in f
            in
              chn, (fun () -> close_in chn)
          )
      | None ->
          (
            stdin, ignore
          )
  in
  let (chn_out, close_out) = 
    match conf.output with
      | Some fn ->
          (
            let chn =
              open_out_bin fn
            in
              chn, (fun () -> close_out chn)
          )
      | None ->
          (
            stdout, ignore
          )
  in
  let t =
    CsvGenerator.input chn_in
  in
  let start_time =
    Unix.gettimeofday ()
  in
  let () = 
    (
      match conf.entries, conf.seed with 
        | Some n, Some seed ->
           CsvGenerator.generate ~progress:progress ~entries:n ~seed:seed t chn_out
        | None, Some seed ->
           CsvGenerator.generate ~progress:progress ~seed:seed t chn_out
        | Some n, None ->
           CsvGenerator.generate ~progress:progress ~entries:n t chn_out
        | None, None ->
           CsvGenerator.generate ~progress:progress t chn_out
    );
    close_in ();
    close_out ()
  in
  let total_time =
    (Unix.gettimeofday ()) -. start_time
  in
    if conf.verbose then
      (
        Printf.eprintf "Elapsed time: %.2fs\n%!" total_time;
        match conf.output with 
          | Some fn ->
              (
                let sz =
                  (Unix.LargeFile.stat fn).Unix.LargeFile.st_size
                in
                let bandwidth =
                  ((Int64.to_float sz) /. total_time) /. (1024.0 *. 1024.0) (* MB/s *)
                in
                  Printf.eprintf "Bandwidth: %.2f MB/s\n%!" bandwidth
              )
          | None ->
              ()
      )
;;


