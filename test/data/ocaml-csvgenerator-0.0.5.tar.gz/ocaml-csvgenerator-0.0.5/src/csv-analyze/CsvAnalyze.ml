(***************************************************************************)
(*  ocaml-csvgenerator : utilities to generate CSV file                    *)
(*                                                                         *)
(*  Copyright (C) 2008 Sylvain Le Gall <sylvain.le-gall@ocamlcore.com>     *)
(*                                                                         *)
(*  This library is free software; you can redistribute it and/or modify   *)
(*  it under the terms of the GNU Lesser General Public License as         *)
(*  published by the Free Software Foundation; either version 2.1 of the   *)
(*  License, or (at your option) any later version; with the special       *)
(*  exception on linking described in the file COPYING at the top of this  *)
(*  source directory.                                                      *)
(*                                                                         *)
(*  This library is distributed in the hope that it will be useful, but    *)
(*  WITHOUT ANY WARRANTY; without even the implied warranty of             *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU      *)
(*  Lesser General Public License for more details.                        *)
(*                                                                         *)
(*  You should have received a copy of the GNU Lesser General Public       *)
(*  License along with this library; if not, write to the Free Software    *)
(*  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307    *)
(*  USA                                                                    *)
(*                                                                         *)
(***************************************************************************)

(** Analyze CSV file 
  *)

type filename = string
;;


type configuration =
    {
      separator:     char;
      input:         filename option;
      output:        filename option;
      filename_list: filename list;
      skip:          int;
      verbose:       bool;
    }
;;

let parse_args () =
  let conf = 
    ref 
      {
        separator     = ';';
        input         = None;
        output        = None;
        filename_list = [];
        skip          = 0;
        verbose       = true; 
      }
  in
  let args =
    [
      ("-t",
       Arg.String
         (
           fun str ->
             conf := {!conf with separator = String.get str 0}
         ),
       "chr Separator of field"
      );

      ("-o",
       Arg.String
         (
           fun str ->
             conf := {!conf with output = Some str}
         ),
       "filename Output file"
      );

      ("-i",
       Arg.String
         (
           fun str ->
             conf := {!conf with input = Some str}
         ),
       "filename Input file to read and merge"
      );

      ("-q",
       Arg.Unit
         (
           fun () ->
             conf := {!conf with verbose = false}
         ),
       " Be quiet"
      );

      ("-s",
       Arg.Int
         (
           fun i -> 
             conf := {!conf with skip = i}
         ),
       "nbr Skip lines"
      );
    ]
  in
    Arg.parse
      (Arg.align args)
      (fun str -> conf := {!conf with filename_list = str :: !conf.filename_list})
      (
        "csv-analyze v"^(CsvGenerator.version)^" written by Sylvain Le Gall <sylvain.le-gall@ocamlcore.com>\n"^
        "\n"^
        "Usage: csv-analyze [option] [input file*]\n"^
        "\n"^
        " Options: \n"
      );
    !conf 
;;

let () =
  let conf =
    parse_args ()
  in
  let progress = 
    if conf.verbose then
      (CsvGenerator.progress "Reading file")
    else
      (fun _ _ -> ())
  in
  let t = 
    match conf.input with 
      | Some f ->
          (
            let chn = open_in_bin f
            in
            let t =
              CsvGenerator.input chn
            in
              close_in chn;
              t
          )
      | None ->
          CsvGenerator.default conf.separator
  in
  let (_, nt) =
    List.fold_left 
      (
        fun (i,t) fn -> 
          (
            i + 1, 
            CsvGenerator.analyze ~progress:(progress i) ~skip:conf.skip fn t
          )
      )
      (1, t)
      conf.filename_list
  in
    match conf.output with
      | Some fn ->
          (
            let chn =
              open_out fn
            in
              CsvGenerator.output chn nt;
              close_out chn
          )
      | None ->
          CsvGenerator.output stdout nt
;;
