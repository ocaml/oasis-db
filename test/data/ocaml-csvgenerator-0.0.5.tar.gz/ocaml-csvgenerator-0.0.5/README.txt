(* OASIS_START *)
(* DO NOT EDIT (digest: 1b366a8c010fc48fe8ebbd4a8579605a) *)
This is the README file for the ocaml-csvgenerator distribution.

(C) 2008-2009 Sylvain Le Gall

Generate random CSV files

The main goal of this project is to provide an easy and convenient way to
produce huge files for testing workload when processing them. Due to
different problems, including size of data, this kind of files cannot be put
into a standard project sources. This software help to keep a kind of
compressed form of this data. This allow in turn to do all the typical
versioning, distribution et al that is done to most project sources do.

Since it uses a statistical approach, their is data loss. However, this is
the intended goal of the project. During the development of this utility, I
wish to have a way to loose the information contains in the huge data file
provided to me. The result is almost the same, in term of statistic, but
loose all the meaning contained in the initial file.

The file generated has enough meaning to be used to stress test programs.

See the files INSTALL.txt for building and installation instructions. See the
file COPYING.txt for copying conditions. 


(* OASIS_STOP *)
