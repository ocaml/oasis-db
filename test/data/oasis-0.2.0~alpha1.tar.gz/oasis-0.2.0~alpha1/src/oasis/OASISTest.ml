
(* END EXPORT *)

let schema = OASISTest_intern.schema
