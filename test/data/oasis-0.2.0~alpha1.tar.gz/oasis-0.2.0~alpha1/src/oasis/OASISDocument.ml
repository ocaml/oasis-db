
(* END EXPORT *)

let schema = OASISDocument_intern.schema
