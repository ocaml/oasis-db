
(* END EXPORT *)

let schema = OASISPackage_intern.schema
