
(* END EXPORT *)

let schema = OASISFlag_intern.schema
