
(* END EXPORT *)

let schema = OASISSourceRepository_intern.schema
