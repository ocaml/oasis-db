
(** Load extra action from plugins
    @author Sylvain Le Gall
  *)

