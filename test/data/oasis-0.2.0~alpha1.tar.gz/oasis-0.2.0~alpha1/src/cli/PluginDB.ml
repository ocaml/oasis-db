
(** Action relative to oasis-db
    @author Sylvain Le Gall
  *)

