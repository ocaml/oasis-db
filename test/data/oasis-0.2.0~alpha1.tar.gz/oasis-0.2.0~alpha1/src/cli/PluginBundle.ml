
(** Actions relative to oasis-bundle
    @author Sylvain Le Gall
  *)

