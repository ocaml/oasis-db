
(** Actions relative to oasis-install
    @author Sylvain Le Gall
  *)

