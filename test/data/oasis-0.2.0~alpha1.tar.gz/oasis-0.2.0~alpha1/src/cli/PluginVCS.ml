
(** Actions relative to oasis-vcs
    @author Sylvain Le Gall
  *)

