open OUnit
open Big_int

let () = 
  let _ = 
    Big_int.big_int_of_string "1234"
  in
    ()
