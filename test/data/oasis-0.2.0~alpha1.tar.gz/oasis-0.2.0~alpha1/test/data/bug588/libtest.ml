
let run () =
  print_endline "hello"

let q = BITSTRING { 1l : 32 }

