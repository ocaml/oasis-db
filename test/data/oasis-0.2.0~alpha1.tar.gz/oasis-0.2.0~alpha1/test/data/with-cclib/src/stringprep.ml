
external caml_stringprep_xmpp_nodeprep : string -> int = "caml_stringprep_xmpp_nodeprep"
