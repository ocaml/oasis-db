let s = "test"

let _ = Stringprep.caml_stringprep_xmpp_nodeprep s
