module Config = CamomileDefaultConfig

module Camomile = CamomileLibrary.Make(Config)
