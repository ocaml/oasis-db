(* OASIS_START *)
(* DO NOT EDIT (digest: f4542e675d35f164b944ae26301fb68d) *)
This is the README file for the ocaml-data-notation distribution.

Store data using OCaml notation

See the files INSTALL.txt for building and installation instructions. See the
file COPYING.txt for copying conditions. 


(* OASIS_STOP *)
