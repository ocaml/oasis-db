(*****************************************************************************)
(*  ocaml-moifile: Everio(TM) .moi file converter                            *)
(*                                                                           *)
(*  Copyright (C) 2010 Sylvain Le Gall                                       *)
(*                                                                           *)
(*  This program is free software; you can redistribute it and/or modify     *)
(*  it under the terms of the GNU General Public License as published by     *)
(*  the Free Software Foundation; either version 2 of the License.           *)
(*                                                                           *)
(*  This program is distributed in the hope that it will be useful,          *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of           *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *)
(*  GNU General Public License for more details.                             *)
(*                                                                           *)
(*  You should have received a copy of the GNU General Public License along  *)
(*  with this program; if not, write to the Free Software Foundation, Inc.,  *)
(*  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.              *)
(*****************************************************************************)

open MOIFileGettext
open FileUtil
open Bitstring
open CalendarLib

(** Some command line options
  *)

let do_link =
  ref false

let dry_run =
  ref false

let verbose =
  ref true

let auto =
  ref false

let args () = 
  [
    "--do-link",
    Arg.Set do_link,
    s_ " Create a symlink from .mod file to .mpg file.";

    "--dry-run",
    Arg.Set dry_run,
    s_ " Do nothing.";

    "--quiet",
    Arg.Clear verbose,
    s_ " Be quiet.";

    "--auto",
    Arg.Set auto,
    s_ " Always choose default answer.";
  ]

(** Printf information 
  *)
let info fmt =
  if !verbose then
    Printf.fprintf stderr ("I: "^^fmt^^"%!\n")
  else
    Printf.ifprintf stderr fmt

let warning fmt =
  if !verbose then
    Printf.fprintf stderr ("W: "^^fmt^^"%!\n")
  else
    Printf.ifprintf stderr fmt

type audio_quality_t =
  | A128kbps
  | A256kbps
  | A384kbps

type video_quality_t =
  | VEconomic
  | VNormal
  | VFine
  | VUltraFine

(** Metadata provided by .moi files
  *)
type moi_t =
    {
      date:          Calendar.t;
      date_reliable: bool;
      seq:           int;
      aspect_ratio:  int * int;
      audio_quality: audio_quality_t;
      video_quality: video_quality_t;
    }

let unreliable_dates =
  [
    Calendar.make 2007 01 01 00 00 00;
  ]

(** Given a .mod file look for .moi and extract
    its information
  *)
let moi_of_mod fn = 
  let fn_moi =
    FilePath.replace_extension fn
      (if FilePath.check_extension fn "mod" then
         "moi"
       else
         "MOI")
  in
    if test Is_file fn_moi then
      begin
        let seq =
          let base_fn =
            FilePath.basename fn
          in
            if String.length base_fn >= 6 then
              Scanf.sscanf (String.sub base_fn 3 3) "%x" (fun i -> i)
            else
              0
        in
        let bits =
          bitstring_of_file fn_moi
        in
          bitmatch bits with
            | {version: 16: string;
               size:    32;
               year:    16;
               month:    8;
               day:      8;
               hour:     8;
               minute:   8;
               ms:      16;
               vlength: 32;
               one:     16;
               zero1: 8*107: string;
               four:     8;
               aspect_ratio:   8;
               svid_quality:   8;
               unknown1:      32;
               a_quality:      8;
               zero2: 8*83: string;
               v_quality:     16
              } ->
                begin
                  let find_or_fail v lst msg =
                      try 
                        List.assoc 
                          v
                          lst
                      with Not_found ->
                        failwith (msg v fn_moi)
                  in
                    assert (version = "V6");
                    assert (one = 1);
                    assert (zero1 = String.make (String.length zero1) '\000');
                    (*assert (zero2 = String.make (String.length zero2) '\000');*)
                    assert (four = 4);
                    assert (unknown1 = 0x010000C1l);
                    assert (svid_quality = 0x00 || svid_quality = 0x18);
                    let date = 
                      Calendar.make year month day hour minute (ms / 1000);
                    in
                      {
                        date = date;
                        date_reliable = 
                          (try 
                             let _d = 
                               List.find 
                                 (fun t -> Calendar.equal t date) 
                                 unreliable_dates
                             in
                               false
                           with Not_found ->
                             true);
                        seq = seq;
                        aspect_ratio = 
                          find_or_fail 
                            aspect_ratio
                            [0x51, (4, 3);
                             0x55, (16, 9)]
                            (Printf.sprintf
                               (f_ "Unknown aspect ratio code %X in file '%s'"));
                        audio_quality = 
                          find_or_fail
                            a_quality
                            [0x05, A128kbps; 
                             0x09, A256kbps;
                             0x0B, A384kbps]
                            (Printf.sprintf 
                               (f_ "Unknown audio quality code %X in file '%s'"));
                        video_quality = 
                          find_or_fail
                            v_quality
                            [0xE51A, VEconomic;
                             0x5ADC, VNormal;
                             0x813D, VFine;
                             0x5896, VUltraFine;
                             (* TODO:
                              * We don't use vquality, so we just add missing 
                              * quality for our version of the Everio(TM) file
                              * format. One day, we will do the test to check 
                              * that we can match quality on the video recorder
                              * and these numbers.
                              *)
                             0x4E04, VEconomic; 
                             0x4874, VFine;
                             0x1774, VFine;
                             0xE1B4, VFine]
                            (Printf.sprintf
                               (f_ "Unknown video quality code %X in file '%s'"));
                      }
                end
            | { _ } ->
               failwith 
                 (Printf.sprintf 
                    (f_ "'%s' is not a .moi file")
                    fn_moi)
      end
    else
      failwith 
        (Printf.sprintf
           (f_ "No .moi file for file %s")
           fn)

let apply_file (fn, fn_mpeg, moi_info) =
  let options =
    ["-i"; Filename.quote fn;
     "-vcodec"; "copy";
     "-ab";
     (match moi_info.audio_quality with
        | A128kbps -> "128k"
        | A256kbps -> "256k"
        | A384kbps -> "384k");
     "-acodec"; "mp2";
    Filename.quote fn_mpeg]

  in
  let fn_mpeg_org = 
    FilePath.add_extension 
      ((FilePath.chop_extension fn_mpeg)^"_org")
      "mpeg"
  in
    if !do_link && not (test Exists fn_mpeg_org) then
      begin
        info (f_ "Symlink '%s' to '%s'") fn fn_mpeg_org;
        Unix.symlink fn fn_mpeg_org
      end;

    if not (test Exists fn_mpeg) then
      begin
        let cmd = 
          String.concat " " ("ffmpeg" :: options)
        in
        let exit_code =
          info (f_ "Execute '%s'") cmd;
          if !dry_run then
            0
          else
            Sys.command cmd
        in
          match exit_code with 
            | 0 -> ()
            | n ->
                failwith 
                  (Printf.sprintf
                     (f_ "Command '%s' exited with error code %d")
                     cmd
                     n)
      end
    else
      begin
        Printf.eprintf 
          (f_ "File '%s', which should be the conversion result of '%s', already exists\n")
          fn_mpeg
          fn
      end

let prepare_file acc fn = 
  let rec ask q dflt f = 
    let a = 
      print_string q; flush stdout; read_line ()
    in
      if a = "" then
        dflt
      else
        begin
          try 
            f a
          with Not_found ->
            begin
              Printf.printf (f_ "'%S' is not an answer") a;
              ask q dflt f 
            end
        end
  in

  let ask_yes_no q dflt = 
    ask
      q
      dflt
      (fun a ->
         List.assoc
           a
           [
             "y", true; 
             s_ "yes", true; 
             "n", false; 
             s_ "no", false;
           ])
  in

    try 
      let moi_info =        
        moi_of_mod fn
      in
      let fn_mpeg =
        FilePath.concat
          (FilePath.dirname fn)
          (FilePath.add_extension
             ("mov-"^
              (if moi_info.date_reliable then
                 begin
                   Printer.Calendar.sprint "%Y%m%d-%H%M" moi_info.date
                 end
               else
                 begin
                   info 
                     (f_ "Date of file '%s' is not reliable, \
                          using sequence number")
                     fn;
                   Printf.sprintf "seq%04d" moi_info.seq
                 end))
             "mpg")
      in
        if test Exists fn_mpeg then
          begin
            info 
              (f_ "Skipping conversion of file '%s', already converted \
                   to '%s'")
              fn fn_mpeg;
            acc
          end
        else if !auto 
          || (ask_yes_no
                (Printf.sprintf (f_ "Convert file '%s' to '%s'? (YES/no)%!") fn fn_mpeg)
                true) then
          (fn, fn_mpeg, moi_info) :: acc
        else 
          acc
    with Failure msg ->
      warning "%s" msg;
      acc

let convert_file fn =
  List.iter
    apply_file 
    (prepare_file [] fn)

let convert_dir fn =
  let lst = 
    find
      (Or ((Has_extension "mod"),
           (Has_extension "MOD")))
      fn 
      prepare_file
      []
  in
    List.iter
      apply_file
      (List.rev lst)

let () = 
  Arg.parse 
    (Arg.align (args ()))
    (fun fn ->
       if Sys.is_directory fn then
         convert_dir fn
       else
         convert_file fn)
    "Everio(TM) file converter by Sylvain Le Gall"

