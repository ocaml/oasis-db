(* OASIS_START *)
(* DO NOT EDIT (digest: 9034e89a6ad133a902780f6c2293e896) *)
This is the README file for the ocaml-moifile distribution.

Extract Video Recorder JVC Everio(TM) files

Hard disk video recorder JVC Everio(TM) generates .mod file, which contains
MPEG2 video and AAC audio, and .moi file, which contains metadata about the
matching .mod file.

This program converts .mod file to MPEG2 video and MP2 audio, which are more
OSS friendly, and uses metadata from .moi file to rename the file using date
of recording.

This program use ffmpeg to do the conversion.

See the files INSTALL.txt for building and installation instructions. See the
file COPYING.txt for copying conditions. 


(* OASIS_STOP *)
