(* OASIS_START *)
(* DO NOT EDIT (digest: 3b85765f21df55979b831f4c840428ee) *)
This is the README file for the ocaml-fastrandom distribution.

(C) 2009 Sylvain Le Gall

Fast random number generator

A random number generator compatible with standard library Random module.

It contains C code to speed up generation and a function to skip a lot of
numbers at once.

See the files INSTALL.txt for building and installation instructions. See the
file COPYING.txt for copying conditions. 

Home page: http://ocaml-fastrandom.forge.ocamlcore.org


(* OASIS_STOP *)
